
create_script_template(here::here("r", "gng", "champ_all_waves_create_gng_subset.R"))
create_script_template(here::here("r", "symmspan", "champ_all_waves_create_sspan_subset.R"))
create_script_template(here::here("r", "demog", "champ_all_waves_create_demog_subset.R"))
